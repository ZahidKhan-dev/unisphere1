import { BrowserRouter as Router, Routes, Route, Navigate, useNavigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './hooks/useAuth';
import { AppLayout } from './components/layout/AppLayout';
import { Home } from './pages/Home';
import { Explore } from './pages/Explore';
import { Upload } from './pages/Upload';
import { HelpHub } from './pages/HelpHub';
import { DepartmentPage } from './pages/Department';
import { AdminPanel } from './pages/Admin';
import { ResourceDetail } from './pages/ResourceDetail';
import { ProtectedRoute, AdminRoute } from './components/auth/ProtectedRoutes';
import { useEffect } from 'react';

function LoginRedirect() {
  const { profile, loading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading && profile) {
      if (profile.role === 'admin') {
        navigate('/admin');
      } else {
        navigate('/student');
      }
    }
  }, [profile, loading, navigate]);

  return <Home />;
}

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <AppLayout>
          <Routes>
            <Route path="/" element={<LoginRedirect />} />
            
            {/* Student Side (Both users and admins can see) */}
            <Route path="/student" element={
              <ProtectedRoute>
                <Home />
              </ProtectedRoute>
            } />
            <Route path="/explore" element={<Explore />} />
            <Route path="/upload" element={
              <ProtectedRoute>
                <Upload />
              </ProtectedRoute>
            } />
            <Route path="/help" element={<HelpHub />} />
            <Route path="/department/:id" element={<DepartmentPage />} />
            <Route path="/resource/:id" element={<ResourceDetail />} />
            
            {/* Admin Side (Only admins) */}
            <Route path="/admin" element={
              <AdminRoute>
                <AdminPanel />
              </AdminRoute>
            } />

            {/* Fallback */}
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </AppLayout>
      </Router>
    </AuthProvider>
  );
}
