import { useState, useEffect, createContext, useContext, ReactNode } from 'react';
import { onAuthStateChanged, User, signInWithPopup, GoogleAuthProvider, signOut } from 'firebase/auth';
import { doc, getDoc, setDoc, onSnapshot } from 'firebase/firestore';
import { auth, db } from '../services/firebase';
import { UserProfile } from '../types';

interface AuthContextType {
  user: User | null;
  profile: UserProfile | null;
  loading: boolean;
  signIn: () => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [signingIn, setSigningIn] = useState(false);

  useEffect(() => {
    let profileUnsubscribe: (() => void) | null = null;
    
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setUser(user);
      
      if (!user) {
        setProfile(null);
        setLoading(false);
        return;
      }

      console.log("Auth state changed: user logged in", user.uid);
      console.log("Using Firebase Project ID:", (auth.app.options as any).projectId);
      const profileRef = doc(db, 'users', user.uid);
      
      const syncProfile = async (retryCount = 0) => {
        try {
          const docSnap = await getDoc(profileRef);
          if (docSnap.exists()) {
            console.log("Profile sync success");
            const profileData = docSnap.data() as UserProfile;
            setProfile(profileData);
            setLoading(false); // SUCCESS: set loading false
          } else {
            console.log("Profile not found, creating one...");
            const isEmailAdmin = user.email === 'yzahid6159@gmail.com';
            const newProfile: UserProfile = {
              uid: user.uid,
              email: user.email || '',
              displayName: user.displayName || 'Student',
              photoURL: user.photoURL || '',
              role: isEmailAdmin ? 'admin' : 'student',
              credits: isEmailAdmin ? 1000 : 0,
              isVerified: isEmailAdmin,
              createdAt: new Date().toISOString(),
            };
            
            // Set optimistically
            setProfile(newProfile);
            await setDoc(profileRef, newProfile);
            console.log("Profile created successfully");
            setLoading(false); // SUCCESS: set loading false
          }
        } catch (error) {
          console.warn(`Profile sync error (attempt ${retryCount + 1}):`, error);
          if (retryCount < 2) {
            setTimeout(() => syncProfile(retryCount + 1), 1000);
          } else {
            console.error("Profile sync failed after retries:", error);
            const { handleFirestoreError, OperationType } = await import('../lib/firebaseUtils');
            handleFirestoreError(error, OperationType.GET, `users/${user.uid}`, false);
            setLoading(false); // FAILED after retries: set loading false anyway to allow access
          }
        }
      };

      syncProfile();
    });

    return () => unsubscribe();
  }, []);

  const signIn = async () => {
    if (signingIn) return;
    setSigningIn(true);
    try {
      console.log("Initiating Google Sign-In...");
      const provider = new GoogleAuthProvider();
      provider.setCustomParameters({ prompt: 'select_account' });
      const result = await signInWithPopup(auth, provider);
      console.log("Sign-in successful, user:", result.user.email);
    } catch (error: any) {
      console.error('Login Error:', error);
      if (error.code === 'auth/cancelled-popup-request') {
        // Silently ignore or show a small toast, but don't alarm the user
        return;
      }
      if (error.code === 'auth/popup-blocked') {
        alert('Login popup was blocked. Please allow popups for this site or open the app in a new tab.');
      } else if (error.code === 'auth/configuration-not-found') {
        alert('Firebase configuration error: Please ensure Google Sign-in is enabled in your Firebase Console.');
      } else if (error.code === 'auth/unauthorized-domain') {
        const domain = window.location.hostname;
        alert(`Authentication failed: This domain (${domain}) is not authorized in your Firebase Console. \n\nTo fix this: \n1. Go to Firebase Console > Auth > Settings > Authorized Domains \n2. Add "${domain}" to the list.`);
      } else {
        alert(`Authentication failed: ${error.message} (${error.code})`);
      }
    } finally {
      setSigningIn(false);
    }
  };

  const logout = async () => {
    await signOut(auth);
  };

  return (
    <AuthContext.Provider value={{ user, profile, loading, signIn, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
