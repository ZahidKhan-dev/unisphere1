import { useState, useEffect } from 'react';
import { collection, query, where, orderBy, onSnapshot, limit, QueryConstraint } from 'firebase/firestore';
import { db } from '../services/firebase';

import { OperationType, handleFirestoreError } from '../lib/firebaseUtils';

const DEFAULT_CONSTRAINTS: QueryConstraint[] = [];

export function useCollection<T>(collectionPath: string, constraints: QueryConstraint[] = DEFAULT_CONSTRAINTS) {
  const [data, setData] = useState<T[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<any>(null);

  useEffect(() => {
    let unsubscribe = () => {};
    let isMounted = true;

    const startListener = () => {
      if (!isMounted) return;
      setLoading(true);
      
      try {
        const q = query(collection(db, collectionPath), ...constraints);
        
        unsubscribe = onSnapshot(q, 
          (snapshot) => {
            if (!isMounted) return;
            const items = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as T));
            setData(items);
            setLoading(false);
            setError(null);
          },
          (err: any) => {
            if (!isMounted) return;
            console.error(`Snapshot listener error for ${collectionPath}:`, err);
            
            // Helpful error for developers
            if (err.message && err.message.includes('index')) {
              console.error(`ACTION REQUIRED: A composite index is required for the query on "${collectionPath}". Click the link in the console or check your Firebase Console Indexes.`);
            }

            // Optional: Still call handleFirestoreError for logging but suppress blocking error UI if desired
            handleFirestoreError(err, OperationType.GET, collectionPath, false);
            
            setError(err);
            setLoading(false);
          }
        );
      } catch (err: any) {
        if (!isMounted) return;
        console.error(`Error creating query for ${collectionPath}:`, err);
        setError(err);
        setLoading(false);
      }
    };

    startListener();

    return () => {
      isMounted = false;
      unsubscribe();
    };
  }, [collectionPath, constraints]);

  return { data, loading, error };
}
