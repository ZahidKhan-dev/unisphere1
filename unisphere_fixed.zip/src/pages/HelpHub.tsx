import React, { useState } from 'react';
import { useCollection } from '../hooks/useCollection';
import { HelpRequest } from '../types';
import { Button } from '../components/common/Button';
import { MessageSquare, Plus } from 'lucide-react';
import { cn } from '../lib/utils';
import { DEPARTMENTS } from '../constants';
import { useAuth } from '../hooks/useAuth';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../services/firebase';

export function HelpHub() {
  const { profile, user } = useAuth();
  const { data: requests, loading } = useCollection<HelpRequest>('helpRequests');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newRequest, setNewRequest] = useState({ title: '', description: '', deptId: '', isPaid: false, budget: 0 });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !profile) return;

    try {
      await addDoc(collection(db, 'helpRequests'), {
        studentId: user.uid,
        studentName: profile.displayName,
        title: newRequest.title,
        description: newRequest.description,
        departmentId: newRequest.deptId,
        status: 'open',
        isPaid: newRequest.isPaid,
        budget: newRequest.isPaid ? newRequest.budget : 0,
        responseCount: 0,
        createdAt: serverTimestamp(),
      });
      setIsModalOpen(false);
      setNewRequest({ title: '', description: '', deptId: '', isPaid: false, budget: 0 });
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="space-y-12">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <h1 className="text-4xl font-serif font-black text-slate-900 leading-tight">Help Hub</h1>
          <p className="text-slate-500 font-medium mt-2 max-w-xl">
            Stuck on a problem? Post a help request and get assistance from peers. 
            Offer help to earn credits and build your academic reputation.
          </p>
        </div>
        <Button className="gap-2" onClick={() => setIsModalOpen(true)}>
          <Plus className="w-5 h-5" /> Post Request
        </Button>
      </header>

      {/* Stats and Filter */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <aside className="space-y-6">
          <div className="bg-white p-6 rounded-2xl border border-slate-200">
            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-widest mb-4">Categories</h3>
            <div className="space-y-2">
              <button className="w-full text-left px-3 py-2 rounded-lg bg-brand-primary/5 text-brand-primary font-bold text-sm">All Requests</button>
              {DEPARTMENTS.slice(0, 6).map(d => (
                <button key={d.id} className="w-full text-left px-3 py-2 rounded-lg text-slate-600 hover:bg-slate-50 text-sm">{d.name}</button>
              ))}
            </div>
          </div>
        </aside>

        <div className="lg:col-span-3 space-y-6">
          {loading ? (
             <div className="space-y-4">
               {[1,2,3].map(i => <div key={i} className="h-32 bg-white border border-slate-200 rounded-2xl animate-pulse"></div>)}
             </div>
          ) : requests.length === 0 ? (
            <div className="text-center py-20 bg-white rounded-3xl border border-dashed border-slate-200">
               <MessageSquare className="w-12 h-12 text-slate-300 mx-auto mb-4" />
               <h3 className="text-lg font-bold text-slate-900">No active help requests</h3>
               <p className="text-slate-500">Be the first to ask for help!</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-4">
              {requests.map((req) => (
                <div key={req.id} className="bg-white p-6 rounded-2xl border border-slate-200 hover:border-brand-primary transition-colors group cursor-pointer">
                  <div className="flex justify-between items-start mb-4">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-bold text-brand-primary uppercase px-2 py-0.5 bg-brand-primary/5 rounded">
                          {DEPARTMENTS.find(d => d.id === req.departmentId)?.code || 'GEN'}
                        </span>
                        <h3 className="text-lg font-bold text-slate-900 group-hover:text-brand-primary transition-colors">{req.title}</h3>
                      </div>
                      <div className="text-xs text-slate-400 font-medium">Posted by {req.studentName} • 2 hours ago</div>
                    </div>
                    {req.isPaid && (
                      <div className="bg-green-500/10 text-green-600 px-3 py-1 rounded-full text-xs font-bold border border-green-100 italic">
                        Budget: {req.budget} Credits
                      </div>
                    )}
                  </div>
                  <p className="text-slate-600 text-sm line-clamp-2 mb-4">{req.description}</p>
                  <div className="flex items-center justify-between pt-4 border-t border-slate-50">
                    <div className="flex items-center gap-4 text-xs font-bold text-slate-400 uppercase tracking-widest">
                      <span className="flex items-center gap-1.5"><MessageSquare className="w-4 h-4" /> {req.responseCount} Responses</span>
                    </div>
                    <Button size="sm" variant="ghost" className="text-brand-primary font-bold">Offer Help</Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Post Request Modal (Simplified) */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white w-full max-w-xl rounded-[32px] overflow-hidden shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="p-8 border-b border-slate-100 flex items-center justify-between">
              <h2 className="text-2xl font-serif font-black text-slate-900">Post Help Request</h2>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-slate-900 transition-colors">
                <Plus className="w-8 h-8 rotate-45" />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="p-8 space-y-6">
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Help Topic</label>
                <input 
                  required
                  type="text" 
                  placeholder="What are you struggling with?"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 px-4 outline-none focus:ring-2 focus:ring-brand-primary/10 transition-all font-medium text-sm"
                  value={newRequest.title}
                  onChange={(e) => setNewRequest({...newRequest, title: e.target.value})}
                />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Department</label>
                <select 
                  required
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 px-4 outline-none focus:ring-2 focus:ring-brand-primary/10 transition-all font-medium text-sm"
                  value={newRequest.deptId}
                  onChange={(e) => setNewRequest({...newRequest, deptId: e.target.value})}
                >
                  <option value="">Select Department</option>
                  {DEPARTMENTS.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Detailed Description</label>
                <textarea 
                  required
                  rows={4}
                  placeholder="Provide details, specific questions, or links to materials..."
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 px-4 outline-none focus:ring-2 focus:ring-brand-primary/10 transition-all font-medium text-sm resize-none"
                  value={newRequest.description}
                  onChange={(e) => setNewRequest({...newRequest, description: e.target.value})}
                />
              </div>
              <div className="flex items-center gap-4 py-2">
                 <label className="flex items-center gap-2 cursor-pointer">
                   <input 
                     type="checkbox" 
                     className="w-5 h-5 accent-brand-primary"
                     checked={newRequest.isPaid}
                     onChange={(e) => setNewRequest({...newRequest, isPaid: e.target.checked})}
                   />
                   <span className="text-sm font-bold text-slate-700">Offer credits as reward</span>
                 </label>
                 {newRequest.isPaid && (
                   <input 
                    type="number" 
                    placeholder="Credits"
                    className="w-24 bg-slate-50 border border-slate-200 rounded-lg py-1 px-3 outline-none focus:ring-2 focus:ring-brand-primary/10 transition-all font-bold text-sm"
                    value={newRequest.budget}
                    onChange={(e) => setNewRequest({...newRequest, budget: Number(e.target.value)})}
                   />
                 )}
              </div>
              <Button type="submit" className="w-full">Create Post</Button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
