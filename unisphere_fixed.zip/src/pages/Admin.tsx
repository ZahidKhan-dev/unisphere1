import { useState, useMemo } from 'react';
import { useCollection } from '../hooks/useCollection';
import { Resource, UserProfile } from '../types';
import { Button } from '../components/common/Button';
import { db } from '../services/firebase';
import { doc, updateDoc, writeBatch, collection, serverTimestamp, Timestamp } from 'firebase/firestore';
import { Check, X, Shield, AlertCircle, TrendingUp, Users, BookOpen } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { DEPARTMENTS } from '../constants';
import { cn } from '../lib/utils';
import { useNavigate } from 'react-router-dom';

export function AdminPanel() {
  const navigate = useNavigate();
  const { profile } = useAuth();
  const noConstraints = useMemo(() => [], []);
  const { data: pendingResources, loading: loadingRes, error: resError } = useCollection<Resource>('resources', noConstraints);
  const { data: users, loading: loadingUsers, error: usersError } = useCollection<UserProfile>('users', noConstraints);

  if (resError || usersError) {
    return (
      <div className="p-8 text-center bg-red-50 rounded-2xl border border-red-100">
        <h2 className="text-xl font-bold text-red-600 mb-2">Admin Access Error</h2>
        <p className="text-red-500 mb-4">You may not have the required permissions to view this data or the rules are still propagating.</p>
        <p className="text-xs text-slate-400 mb-6">User: {profile?.email} | ID: {profile?.uid}</p>
        <Button onClick={() => window.location.reload()}>Retry Access</Button>
      </div>
    );
  }
  const handleStatus = async (id: string, status: 'approved' | 'rejected') => {
    try {
      await updateDoc(doc(db, 'resources', id), {
        status,
        updatedAt: serverTimestamp(),
      });
    } catch (err) {
      console.error(err);
    }
  };

  const seedData = async () => {
    const batch = writeBatch(db);
    
    // Seed Departments
    DEPARTMENTS.forEach(dept => {
      const ref = doc(db, 'departments', dept.id);
      batch.set(ref, {
        ...dept,
        description: `Official academic resources for ${dept.name}.`,
        createdAt: serverTimestamp()
      });
    });

    // Seed some initial resources
    const sampleResources = [
      {
        title: "Introduction to Data Structures",
        description: "Comprehensive notes covering stacks, queues, and linked lists.",
        departmentId: "cs",
        courseCode: "CS-102",
        semester: 2,
        type: "Notes",
        isFree: true,
        price: 0,
        uploaderId: "system",
        uploaderName: "UniSphere Library",
        status: "approved",
        downloadCount: 450,
        rating: 4.8,
        reviewCount: 24,
        tags: ["programming", "dsa"],
        fileUrl: "#",
        fileType: "application/pdf"
      },
      {
        title: "Mechanical Engineering Statics - 2024 Past Paper",
        description: "Final exam paper with partial solutions.",
        departmentId: "me",
        courseCode: "ME-201",
        semester: 3,
        type: "Past Papers",
        isFree: false,
        price: 15,
        uploaderId: "system",
        uploaderName: "Archive Bot",
        status: "approved",
        downloadCount: 120,
        rating: 4.5,
        reviewCount: 12,
        tags: ["mechanics", "exam"],
        fileUrl: "#",
        fileType: "application/pdf"
      }
    ];

    sampleResources.forEach(res => {
      const ref = doc(collection(db, 'resources'));
      batch.set(ref, {
        ...res,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });
    });

    await batch.commit();
    alert('Database seeded with standard departments and sample resources!');
  };

  if (!profile || profile.role !== 'admin') {
    return (
      <div className="flex flex-col items-center justify-center py-20 bg-white rounded-3xl border border-red-100">
        <AlertCircle className="w-16 h-16 text-red-500 mb-6" />
        <h2 className="text-2xl font-serif font-black text-slate-900 mb-2">Access Restrained</h2>
        <p className="text-slate-500 mb-8 max-w-xs text-center">Only authorized academic administrators can access this control panel.</p>
        <div className="flex flex-col gap-4">
           <Button onClick={() => window.location.href = '/'}>Go back Home</Button>
           {/* Temporary developer backdoor to make oneself admin for testing */}
           <Button variant="outline" onClick={async () => {
             if (profile) {
               const batch = writeBatch(db);
               batch.update(doc(db, 'users', profile.uid), { role: 'admin' });
               batch.set(doc(db, 'admins', profile.uid), { 
                 email: profile.email,
                 grantedAt: serverTimestamp(),
                 grantedBy: 'system_dev'
               });
               await batch.commit();
               alert('You are now an admin. Refresh the page.');
             }
           }}>Grant Me Admin (Dev Mode)</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-12 pb-20">
      <header className="flex items-end justify-between">
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-brand-primary font-bold uppercase tracking-widest text-xs">
            <Shield className="w-4 h-4" /> System Administrator
          </div>
          <h1 className="text-4xl font-serif font-black text-slate-900 leading-tight tracking-tight">Enterprise Console</h1>
        </div>
        <div className="flex gap-4">
          <Button variant="outline" onClick={() => navigate('/student')}>View User Side</Button>
          <Button variant="outline" onClick={seedData}>Seed Standard Data</Button>
        </div>
      </header>

      {/* Analytics Row */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {[
          { label: 'Total Scholars', value: users.length, icon: Users, color: 'bg-blue-500' },
          { label: 'Published Resources', value: pendingResources.length, icon: BookOpen, color: 'bg-indigo-500' },
          { label: 'Recent Contributions', value: pendingResources.filter(r => {
            const now = new Date();
            const created = r.createdAt instanceof Timestamp ? r.createdAt.toDate() : new Date(r.createdAt);
            return (now.getTime() - created.getTime()) < (24 * 60 * 60 * 1000);
          }).length, icon: TrendingUp, color: 'bg-green-500' },
        ].map((stat, i) => (
          <div key={i} className="bg-white p-8 rounded-2xl border border-slate-200">
            <div className="flex items-center justify-between mb-4">
              <div className={cn("p-3 rounded-xl text-white", stat.color)}>
                <stat.icon className="w-6 h-6" />
              </div>
              <TrendingUp className="w-5 h-5 text-slate-300" />
            </div>
            <div className="text-4xl font-black text-slate-900">{stat.value}</div>
            <div className="text-xs font-bold text-slate-400 uppercase tracking-widest mt-2">{stat.label}</div>
          </div>
        ))}
      </div>

      {/* Resource Audit */}
      <section className="space-y-6">
        <h2 className="text-2xl font-serif font-bold text-slate-900">Recent Resource Activity</h2>
        <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-sm">
          <table className="w-full text-left">
            <thead className="bg-slate-50 border-b border-slate-100">
              <tr>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-widest">Resource</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-widest">Department</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-widest">Contributor</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-widest">Status</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-widest text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {pendingResources.sort((a,b) => {
                const dateA = a.createdAt instanceof Timestamp ? a.createdAt.toMillis() : new Date(a.createdAt).getTime();
                const dateB = b.createdAt instanceof Timestamp ? b.createdAt.toMillis() : new Date(b.createdAt).getTime();
                return dateB - dateA;
              }).slice(0, 10).map((res) => (
                <tr key={res.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="px-6 py-5">
                    <div className="font-bold text-slate-900">{res.title}</div>
                    <div className="text-xs text-slate-400">{res.type} • {res.courseCode}</div>
                  </td>
                  <td className="px-6 py-5">
                    <span className="text-xs font-bold text-brand-primary bg-brand-primary/5 px-2 py-1 rounded">
                      {DEPARTMENTS.find(d => d.id === res.departmentId)?.name}
                    </span>
                  </td>
                  <td className="px-6 py-5 text-sm text-slate-600 font-medium">{res.uploaderName}</td>
                  <td className="px-6 py-5">
                    <span className={cn(
                      "text-[10px] font-black uppercase px-2 py-1 rounded-full border",
                      res.status === 'approved' ? "text-green-600 bg-green-50 border-green-100" : "text-orange-500 bg-orange-50 border-orange-100"
                    )}>
                      {res.status}
                    </span>
                  </td>
                  <td className="px-6 py-5 text-right">
                    <div className="flex items-center justify-end gap-2">
                       <button 
                        onClick={() => handleStatus(res.id, 'rejected')}
                        title="Unpublish"
                        className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all"
                       >
                         <X className="w-5 h-5" />
                       </button>
                    </div>
                  </td>
                </tr>
              ))}
              {pendingResources.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-6 py-12 text-center text-slate-400 font-medium italic">
                    No resources found in the system.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>

      {/* User Management */}
      <section className="space-y-6">
        <h2 className="text-2xl font-serif font-bold text-slate-900">Registered Scholars</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {users.map((u) => (
            <div key={u.uid} className="bg-white p-5 rounded-xl border border-slate-200 flex items-center gap-4">
              <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center font-bold text-brand-primary">
                {u.displayName.charAt(0)}
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-bold text-slate-900 truncate">{u.displayName}</div>
                <div className="text-xs text-slate-500 truncate">{u.email}</div>
              </div>
              <div className="text-right">
                <div className={cn("text-[10px] font-black uppercase px-2 py-0.5 rounded", 
                  u.role === 'admin' ? "bg-red-50 text-red-600" : "bg-slate-100 text-slate-600"
                )}>
                  {u.role}
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
