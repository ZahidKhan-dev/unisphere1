import React, { useMemo } from 'react';
import { BookOpen, Upload, Users, GraduationCap, ArrowRight, TrendingUp, Star, Clock } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { Button } from '../components/common/Button';
import { Link } from 'react-router-dom';
import { useCollection } from '../hooks/useCollection';
import { Resource } from '../types';
import { ResourceGrid } from '../components/resources/ResourceGrid';
import { where, limit, orderBy } from 'firebase/firestore';
import { cn } from '../lib/utils';

export function Home() {
  const { profile, signIn, loading: authLoading } = useAuth();
  
  const constraints = useMemo(() => [
    limit(8)
  ], []);

  const { data: featuredResources, loading: resourcesLoading, error: resourcesError } = useCollection<Resource>('resources', constraints);

  const { data: departments, error: deptsError, loading: deptsLoading } = useCollection('departments');
  
  if (authLoading) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-brand-primary border-t-transparent rounded-full animate-spin"></div>
          <p className="text-slate-500 font-medium animate-pulse">Initializing Hub...</p>
        </div>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="flex flex-col gap-24 py-12">
        {/* Hero Section */}
        <section className="flex flex-col lg:flex-row items-center gap-16">
          <div className="flex-1 space-y-8">
            <div className="inline-flex items-center gap-2 bg-brand-primary/5 px-4 py-2 rounded-full border border-brand-primary/10">
              <GraduationCap className="w-5 h-5 text-brand-primary" />
              <span className="text-sm font-bold text-brand-primary uppercase tracking-wider italic">UniSphere Academic Hub</span>
            </div>
            
            <h1 className="text-6xl lg:text-7xl font-serif font-black text-slate-900 leading-[1.1] tracking-tight">
              Elevate your <span className="text-brand-primary">Academic Journey</span> with Peer Support.
            </h1>
            
            <p className="text-xl text-slate-600 max-w-xl leading-relaxed">
              A collaborative ecosystem where university students share resources, help each other, and monetize their high-quality academic content.
            </p>
            
            <div className="flex items-center gap-4">
              <Button size="lg" onClick={() => signIn()}>Get Started Now</Button>
              <Button size="lg" variant="outline">Learn More</Button>
            </div>
          </div>
          
          <div className="flex-1 relative">
            <div className="aspect-square bg-brand-primary/5 rounded-full absolute -z-10 -top-8 -right-8 w-full h-full blur-3xl"></div>
            <div className="bg-white p-8 rounded-3xl shadow-2xl shadow-slate-200 border border-slate-100 rotate-2 hover:rotate-0 transition-transform duration-500">
              <div className="space-y-6">
                <div className="flex items-center gap-4 p-4 bg-slate-50 rounded-2xl border border-slate-100">
                  <div className="w-12 h-12 bg-green-500 rounded-xl flex items-center justify-center text-white font-bold">PDF</div>
                  <div>
                    <div className="font-bold text-slate-900">CS-201 Final Prep Notes</div>
                    <div className="text-xs text-slate-500">Shared by Sarah Q. • Computer Science</div>
                  </div>
                </div>
                <div className="flex items-center gap-4 p-4 bg-slate-50 rounded-2xl border border-slate-100">
                  <div className="w-12 h-12 bg-blue-500 rounded-xl flex items-center justify-center text-white font-bold">SOL</div>
                  <div>
                    <div className="font-bold text-slate-900">Advanced Calculus Solutions</div>
                    <div className="text-xs text-slate-500">Shared by Mike R. • Mathematics</div>
                  </div>
                </div>
                <div className="flex items-center justify-between pt-4">
                  <div className="text-sm font-medium text-slate-500 italic">4.9k+ resources uploaded this week</div>
                  <TrendingUp className="w-5 h-5 text-green-500" />
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            { label: 'Active Students', value: '12k+', icon: Users, color: 'text-blue-500' },
            { label: 'Departments', value: '10+', icon: GraduationCap, color: 'text-brand-primary' },
            { label: 'Paid Payouts', value: '$45k+', icon: TrendingUp, color: 'text-green-500' },
          ].map((stat, i) => (
            <div key={i} className="bg-white p-8 rounded-2xl border border-slate-200 flex flex-col items-center text-center group hover:border-brand-primary transition-colors">
              <div className={cn("p-4 rounded-xl bg-slate-50 mb-6 group-hover:bg-brand-primary group-hover:text-white transition-colors", stat.color)}>
                <stat.icon className="w-8 h-8" />
              </div>
              <div className="text-4xl font-serif font-black text-slate-900 mb-2">{stat.value}</div>
              <div className="text-sm font-medium text-slate-500 uppercase tracking-widest">{stat.label}</div>
            </div>
          ))}
        </section>
      </div>
    );
  }

  const renderError = (title: string, message: string) => (
    <div className="p-8 bg-red-50 border border-red-100 rounded-2xl text-center">
      <h3 className="text-lg font-bold text-red-800 mb-2">{title}</h3>
      <p className="text-sm text-red-600 mb-4">{message}</p>
      <Button size="sm" variant="outline" onClick={() => window.location.reload()}>Retry</Button>
    </div>
  );

  // Logged-in Dashboard
  return (
    <div className="space-y-12">
      <header className="flex items-end justify-between">
        <div>
          <h1 className="text-4xl font-serif font-black text-slate-900 leading-tight">
            Welcome back, {profile.displayName.split(" ")[0]}!
          </h1>
          <p className="text-slate-500 mt-2 font-medium">Here's what's happening in your academic circle today.</p>
        </div>
        <Link to="/upload">
          <Button className="gap-2">
            <Upload className="w-4 h-4" />
            Upload Resource
          </Button>
        </Link>
      </header>

      {/* Quick Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {[
          { label: 'Earned Credits', value: profile.credits, icon: Star, color: 'bg-yellow-400' },
          { label: 'Purchased', value: '12', icon: BookOpen, color: 'bg-blue-400' },
          { label: 'Your Uploads', value: '3', icon: Upload, color: 'bg-brand-primary' },
          { label: 'Verified', value: profile.isVerified ? 'Yes' : 'No', icon: GraduationCap, color: 'bg-green-400' },
        ].map((stat, i) => (
          <div key={i} className="bg-white p-6 rounded-xl border border-slate-200 flex items-center gap-4">
            <div className={cn("w-12 h-12 rounded-lg flex items-center justify-center text-white", stat.color)}>
              <stat.icon className="w-6 h-6" />
            </div>
            <div>
              <div className="text-2xl font-black text-slate-900 leading-none">{stat.value}</div>
              <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mt-1">{stat.label}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Featured Resources */}
      <section>
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-2xl font-serif font-bold text-slate-900 flex items-center gap-2">
            <TrendingUp className="w-6 h-6 text-brand-primary" />
            Most Downloaded
          </h2>
          <Link to="/explore">
            <Button variant="ghost" className="text-brand-primary group">
              View All <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
            </Button>
          </Link>
        </div>
        {resourcesError ? (
          resourcesError.message?.includes("index") ? (
            renderError("Index Required", "This section requires a composite index in Firestore. Check your browser console for the direct link to create it.")
          ) : (
            renderError("Resources Unavailable", "We couldn't load the featured resources. Check your Firestore rules or project configuration.")
          )
        ) : (
          <ResourceGrid resources={featuredResources} loading={resourcesLoading} />
        )}
      </section>

      {/* Departments Grid */}
      <section className="bg-brand-primary/5 rounded-[32px] p-12 border border-brand-primary/10">
        <h2 className="text-3xl font-serif font-bold text-slate-900 mb-8 text-center">Browse by Department</h2>
        {deptsError ? (
          renderError("Departments Unavailable", "We couldn't load the departments list. Please ensure the 'departments' collection exists and has public read access.")
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-5 gap-6">
            {departments.length > 0 ? (
              departments.slice(0, 10).map((dept: any) => (
                <Link 
                  key={dept.id} 
                  to={`/department/${dept.id}`}
                  className="bg-white p-6 rounded-2xl border border-slate-100 flex flex-col items-center justify-center gap-4 hover:shadow-lg hover:-translate-y-1 transition-all group"
                >
                  <div className="w-12 h-12 rounded-xl bg-slate-50 flex items-center justify-center text-brand-primary group-hover:bg-brand-primary group-hover:text-white transition-colors">
                    <GraduationCap className="w-6 h-6" />
                  </div>
                  <span className="text-sm font-bold text-slate-900 text-center">{dept.name}</span>
                </Link>
              ))
            ) : (
              <div className="col-span-full py-12 flex flex-col items-center gap-4 text-slate-400">
                <BookOpen className="w-12 h-12 opacity-20" />
                <p>No departments found. Admins should seed the 'departments' collection.</p>
              </div>
            )}
          </div>
        )}
      </section>
    </div>
  );
}
