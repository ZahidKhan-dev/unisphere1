import React, { useState } from 'react';
import { useAuth } from '../hooks/useAuth';
import { Button } from '../components/common/Button';
import { DEPARTMENTS, RESOURCE_TYPES, SEMESTERS } from '../constants';
import { db } from '../services/firebase';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { Upload as UploadIcon, FileText, CheckCircle2, AlertCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

// ─── CLOUDINARY CONFIG ────────────────────────────────────────────────────────
// 1. Sign up free at https://cloudinary.com
// 2. Go to Settings → Upload → Upload Presets → Add unsigned preset
// 3. Replace these two values:
const CLOUDINARY_CLOUD_NAME = 'YOUR_CLOUD_NAME';       // e.g. 'dxyz123abc'
const CLOUDINARY_UPLOAD_PRESET = 'unisphere_uploads';  // your unsigned preset name
// ─────────────────────────────────────────────────────────────────────────────

async function uploadToCloudinary(file: File, onProgress?: (pct: number) => void): Promise<string> {
  const formData = new FormData();
  formData.append('file', file);
  formData.append('upload_preset', CLOUDINARY_UPLOAD_PRESET);
  formData.append('folder', 'unisphere');

  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();

    xhr.upload.addEventListener('progress', (e) => {
      if (e.lengthComputable && onProgress) {
        onProgress(Math.round((e.loaded / e.total) * 100));
      }
    });

    xhr.addEventListener('load', () => {
      if (xhr.status === 200) {
        const data = JSON.parse(xhr.responseText);
        resolve(data.secure_url);
      } else {
        let errMsg = `Upload failed (${xhr.status})`;
        try {
          const errData = JSON.parse(xhr.responseText);
          errMsg = errData.error?.message || errMsg;
        } catch {}
        reject(new Error(errMsg));
      }
    });

    xhr.addEventListener('error', () => reject(new Error('Network error during file upload')));
    xhr.addEventListener('abort', () => reject(new Error('File upload was aborted')));

    xhr.open('POST', `https://api.cloudinary.com/v1_1/${CLOUDINARY_CLOUD_NAME}/auto/upload`);
    xhr.send(formData);
  });
}

export function Upload() {
  const { profile, user, signIn } = useAuth();
  const navigate = useNavigate();
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [formData, setFormData] = useState({
    title: '',
    description: '',
    departmentId: '',
    courseCode: '',
    semester: 1,
    type: 'Notes',
    isFree: true,
    price: 0,
    tags: '',
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selected = e.target.files[0];
      if (selected.size > 25 * 1024 * 1024) {
        setError('File is too large. Maximum size is 25MB.');
        return;
      }
      setFile(selected);
      setError(null);
    }
  };

  const handleUpload = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!file) { setError('Please select a file to upload.'); return; }
    if (!user) { setError('You must be signed in to upload.'); return; }
    if (!profile) { setError('Profile not loaded yet. Please wait a moment and try again.'); return; }
    if (!formData.departmentId) { setError('Please select a department.'); return; }

    if (CLOUDINARY_CLOUD_NAME === 'YOUR_CLOUD_NAME') {
      setError('Cloudinary is not configured yet. Open Upload.tsx and set CLOUDINARY_CLOUD_NAME and CLOUDINARY_UPLOAD_PRESET.');
      return;
    }

    setLoading(true);
    setError(null);
    setUploadProgress(0);

    try {
      // Step 1: Upload file to Cloudinary
      console.log('Uploading file to Cloudinary...');
      const fileUrl = await uploadToCloudinary(file, setUploadProgress);
      console.log('File uploaded successfully:', fileUrl);

      // Step 2: Save metadata to Firestore
      console.log('Saving metadata to Firestore...');
      const resourceData = {
        title: formData.title,
        description: formData.description,
        departmentId: formData.departmentId,
        courseCode: formData.courseCode.toUpperCase(),
        semester: formData.semester,
        type: formData.type,
        fileUrl,
        fileType: file.type,
        fileName: file.name,
        isFree: formData.isFree,
        price: formData.isFree ? 0 : Number(formData.price),
        uploaderId: user.uid,
        uploaderName: profile.displayName || user.email || 'Anonymous Student',
        status: 'approved',
        downloadCount: 0,
        rating: 0,
        reviewCount: 0,
        tags: formData.tags.split(',').map((tag: string) => tag.trim()).filter(Boolean),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      };

      await addDoc(collection(db, 'resources'), resourceData);
      console.log('Metadata saved to Firestore successfully.');

      setSuccess(true);
      setTimeout(() => {
        navigate(profile.role === 'admin' ? '/admin' : '/');
      }, 3000);

    } catch (err: any) {
      console.error('Upload failed:', err);
      let message = 'Upload failed. Please try again.';

      if (err.message?.includes('Upload failed')) {
        message = `File upload error: ${err.message}. Check your Cloudinary preset is set to "Unsigned".`;
      } else if (err.code === 'permission-denied') {
        message = 'Database permission denied. Check your Firestore security rules in Firebase Console.';
      } else if (err.message) {
        message = err.message;
      }

      setError(message);
    } finally {
      setLoading(false);
      setUploadProgress(0);
    }
  };

  if (!profile) {
    return (
      <div className="flex flex-col items-center justify-center py-20 bg-white rounded-3xl border border-dashed border-slate-200">
        <UploadIcon className="w-16 h-16 text-slate-300 mb-6" />
        <h2 className="text-2xl font-serif font-black text-slate-900 mb-2">Login Required</h2>
        <p className="text-slate-500 mb-8 max-w-xs text-center">Please sign in with your university account to start sharing resources.</p>
        <div className="flex flex-col gap-4">
          <Button onClick={signIn}>Sign In with Google</Button>
          <Button variant="outline" onClick={() => navigate('/')}>Go back Home</Button>
        </div>
      </div>
    );
  }

  if (success) {
    return (
      <div className="flex flex-col items-center justify-center py-20 bg-white rounded-3xl border border-green-100 animate-in fade-in zoom-in duration-300">
        <div className="w-20 h-20 bg-green-500 rounded-full flex items-center justify-center text-white mb-6">
          <CheckCircle2 className="w-10 h-10" />
        </div>
        <h2 className="text-3xl font-serif font-black text-slate-900 mb-2">Submission Successful!</h2>
        <p className="text-slate-500 mb-8 max-w-sm text-center">
          Your resource has been published and is now available for your peers to download.
        </p>
        <div className="flex gap-4">
          <Button variant="outline" onClick={() => {
            setSuccess(false); setFile(null);
            setFormData({ title: '', description: '', departmentId: '', courseCode: '', semester: 1, type: 'Notes', isFree: true, price: 0, tags: '' });
          }}>
            Upload Another
          </Button>
          <Button onClick={() => navigate('/')}>Return to Dashboard</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-12">
      <header>
        <h1 className="text-4xl font-serif font-black text-slate-900 leading-tight">Share Resource</h1>
        <p className="text-slate-500 font-medium mt-2">
          Contributors earn credits for every high-quality resource shared. Help your peers and build your profile.
        </p>
      </header>

      <form onSubmit={handleUpload} className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-white p-8 rounded-2xl border border-slate-200 space-y-6">
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Resource Title</label>
              <input
                required
                type="text"
                placeholder="e.g. CS201 Final Exam Prep (2025)"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 px-4 outline-none focus:ring-2 focus:ring-brand-primary/10 focus:border-brand-primary transition-all font-medium"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Description & Context</label>
              <textarea
                required
                rows={4}
                placeholder="What does this resource cover? Any tips for study?"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 px-4 outline-none focus:ring-2 focus:ring-brand-primary/10 focus:border-brand-primary transition-all font-medium resize-none"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Upload File</label>
              <div className="border-2 border-dashed border-slate-200 rounded-2xl p-8 text-center hover:border-brand-primary transition-colors cursor-pointer relative">
                <input
                  required
                  type="file"
                  accept=".pdf,.doc,.docx,.zip,.png,.jpg,.jpeg,.ppt,.pptx"
                  className="absolute inset-0 opacity-0 cursor-pointer"
                  onChange={handleFileChange}
                />
                <div className="space-y-2">
                  <div className="w-12 h-12 bg-slate-100 rounded-full flex items-center justify-center mx-auto text-slate-400">
                    <FileText className="w-6 h-6" />
                  </div>
                  {file ? (
                    <div>
                      <div className="text-sm font-bold text-brand-primary">{file.name}</div>
                      <div className="text-xs text-slate-400 mt-1">{(file.size / (1024 * 1024)).toFixed(2)} MB</div>
                    </div>
                  ) : (
                    <>
                      <div className="text-sm font-bold text-slate-900">Click or drag to upload</div>
                      <div className="text-xs text-slate-400">PDF, DOCX, ZIP or Images (Max 25MB)</div>
                    </>
                  )}
                </div>
              </div>

              {loading && uploadProgress > 0 && uploadProgress < 100 && (
                <div className="space-y-1">
                  <div className="flex justify-between text-xs text-slate-500">
                    <span>Uploading file...</span>
                    <span>{uploadProgress}%</span>
                  </div>
                  <div className="w-full bg-slate-100 rounded-full h-2">
                    <div
                      className="bg-brand-primary h-2 rounded-full transition-all duration-300"
                      style={{ width: `${uploadProgress}%` }}
                    />
                  </div>
                </div>
              )}
              {loading && uploadProgress === 0 && (
                <p className="text-xs text-slate-400 text-center animate-pulse">Preparing upload...</p>
              )}
              {loading && uploadProgress === 100 && (
                <p className="text-xs text-slate-400 text-center animate-pulse">Saving to database...</p>
              )}
            </div>
          </div>
        </div>

        <div className="space-y-8">
          <div className="bg-slate-900 p-8 rounded-2xl text-white space-y-6">
            <h3 className="text-lg font-serif font-bold">Classification</h3>
            <div className="space-y-4">
              <div className="space-y-1.5 text-xs">
                <label className="font-bold opacity-60 uppercase tracking-wider">Department</label>
                <select
                  required
                  className="w-full bg-white/10 border border-white/20 rounded-lg py-2 px-3 outline-none focus:ring-2 focus:ring-white/20"
                  value={formData.departmentId}
                  onChange={(e) => setFormData({ ...formData, departmentId: e.target.value })}
                >
                  <option value="" className="text-slate-900">Select Department</option>
                  {DEPARTMENTS.map(d => <option key={d.id} value={d.id} className="text-slate-900">{d.name}</option>)}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5 text-xs">
                  <label className="font-bold opacity-60 uppercase tracking-wider">Course Code</label>
                  <input
                    required
                    type="text"
                    placeholder="CS-201"
                    className="w-full bg-white/10 border border-white/20 rounded-lg py-2 px-3 outline-none focus:ring-2 focus:ring-white/20 uppercase"
                    value={formData.courseCode}
                    onChange={(e) => setFormData({ ...formData, courseCode: e.target.value })}
                  />
                </div>
                <div className="space-y-1.5 text-xs">
                  <label className="font-bold opacity-60 uppercase tracking-wider">Semester</label>
                  <select
                    className="w-full bg-white/10 border border-white/20 rounded-lg py-2 px-3 outline-none focus:ring-2 focus:ring-white/20"
                    value={formData.semester}
                    onChange={(e) => setFormData({ ...formData, semester: Number(e.target.value) })}
                  >
                    {SEMESTERS.map(s => <option key={s} value={s} className="text-slate-900">Sem {s}</option>)}
                  </select>
                </div>
              </div>

              <div className="space-y-1.5 text-xs">
                <label className="font-bold opacity-60 uppercase tracking-wider">Resource Type</label>
                <select
                  className="w-full bg-white/10 border border-white/20 rounded-lg py-2 px-3 outline-none focus:ring-2 focus:ring-white/20"
                  value={formData.type}
                  onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                >
                  {RESOURCE_TYPES.map(t => <option key={t} value={t} className="text-slate-900">{t}</option>)}
                </select>
              </div>
            </div>
          </div>

          <div className="bg-white p-8 rounded-2xl border border-slate-200 space-y-6">
            <h3 className="text-lg font-serif font-bold text-slate-900">Monetization</h3>

            <div className="flex items-center justify-between p-4 bg-slate-50 rounded-xl">
              <div className="space-y-1">
                <div className="text-sm font-bold text-slate-900">Free Resource</div>
                <div className="text-[10px] text-slate-500">Available to all students</div>
              </div>
              <input
                type="checkbox"
                checked={formData.isFree}
                onChange={(e) => setFormData({ ...formData, isFree: e.target.checked })}
                className="w-5 h-5 accent-brand-primary"
              />
            </div>

            {!formData.isFree && (
              <div className="space-y-2 animate-in slide-in-from-top-2 duration-300">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Price (Credits)</label>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-bold">C</span>
                  <input
                    type="number"
                    min={1}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 pl-8 pr-4 outline-none focus:ring-2 focus:ring-brand-primary/10 transition-all font-bold"
                    value={formData.price}
                    onChange={(e) => setFormData({ ...formData, price: Number(e.target.value) })}
                  />
                </div>
              </div>
            )}

            {error && (
              <div className="p-4 bg-red-50 border border-red-100 rounded-xl flex gap-3 text-red-600 text-sm">
                <AlertCircle className="w-5 h-5 shrink-0 mt-0.5" />
                <span>{error}</span>
              </div>
            )}

            <div className="space-y-4">
              <Button
                type="submit"
                className="w-full"
                loading={loading}
                disabled={!file || loading}
              >
                {loading
                  ? (uploadProgress > 0 && uploadProgress < 100 ? `Uploading ${uploadProgress}%` : 'Saving...')
                  : 'Publish Resource'}
              </Button>
              <p className="text-[10px] text-slate-400 text-center leading-relaxed">
                By submitting, you agree to follow academic integrity guidelines. Your resource will be immediately available to the UniSphere community.
              </p>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
}
