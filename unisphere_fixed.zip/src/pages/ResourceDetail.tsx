import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { doc, getDoc, updateDoc, collection, addDoc, serverTimestamp, increment, Timestamp } from 'firebase/firestore';
import { db } from '../services/firebase';
import { Resource, UserProfile } from '../types';
import { useAuth } from '../hooks/useAuth';
import { Button } from '../components/common/Button';
import { FileText, Download, Star, Lock, CheckCircle2, AlertCircle, ArrowLeft, Coins, Clock } from 'lucide-react';
import { DEPARTMENTS } from '../constants';
import { cn } from '../lib/utils';
import { handleFirestoreError, OperationType } from '../lib/firebaseUtils';

export function ResourceDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { profile, user } = useAuth();
  const [resource, setResource] = useState<Resource | null>(null);
  const [loading, setLoading] = useState(true);
  const [purchasing, setPurchasing] = useState(false);
  const [hasAccess, setHasAccess] = useState(false);

  useEffect(() => {
    async function fetchResource() {
      if (!id) return;
      setLoading(true);
      try {
        const docRef = doc(db, 'resources', id);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          const data = { id: docSnap.id, ...docSnap.data() } as Resource;
          setResource(data);
          
          // Check access: is owner, is admin, is free, or already purchased (simplified for MVP: user is uploader or it's free)
          if (user && (data.uploaderId === user.uid || data.isFree)) {
            setHasAccess(true);
          }
        } else {
          console.warn("Resource not found:", id);
        }
      } catch (err: any) {
        console.error("Error fetching resource:", err);
        handleFirestoreError(err, OperationType.GET, `resources/${id}`, false);
      } finally {
        setLoading(false);
      }
    }
    fetchResource();
  }, [id, user]);

  const handlePurchase = async () => {
    if (!resource || !profile || !user) return;
    if (profile.credits < resource.price) {
      alert("Insufficient credits. Contribute more resources to earn credits!");
      return;
    }

    setPurchasing(true);
    try {
      // 1. Deduct credits from buyer
      await updateDoc(doc(db, 'users', user.uid), {
        credits: increment(-resource.price)
      });

      // 2. Add credits to uploader (payout logic)
      await updateDoc(doc(db, 'users', resource.uploaderId), {
        credits: increment(resource.price)
      });

      // 3. Create transaction log
      await addDoc(collection(db, 'transactions'), {
        userId: user.uid,
        amount: resource.price,
        type: 'resource_purchase',
        resourceId: resource.id,
        description: `Purchased ${resource.title}`,
        createdAt: serverTimestamp()
      });

      // 4. Update download count
      await updateDoc(doc(db, 'resources', resource.id), {
        downloadCount: increment(1)
      });

      setHasAccess(true);
      alert("Purchase successful! You can now download the file.");
    } catch (err: any) {
      console.error("Purchase failed:", err);
      handleFirestoreError(err, OperationType.UPDATE, `resources/${resource.id}`, false);
      
      let message = "Transaction failed. Please try again.";
      if (err.message && err.message.includes('permission')) {
        message = "Permission Denied: Your transaction was blocked by security rules. Ensure your profile is correctly initialized.";
      }
      alert(message);
    } finally {
      setPurchasing(false);
    }
  };

  const handleDownload = () => {
    if (resource?.fileUrl) {
      window.open(resource.fileUrl, '_blank');
    }
  };

  if (loading) return <div className="p-20 text-center animate-pulse">Loading academic assets...</div>;
  if (!resource) return <div className="p-20 text-center">Resource not found.</div>;

  const dept = DEPARTMENTS.find(d => d.id === resource.departmentId);

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <button 
        onClick={() => navigate(-1)} 
        className="flex items-center gap-2 text-slate-500 hover:text-brand-primary font-bold text-sm transition-colors group"
      >
        <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
        Back to Explore
      </button>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-white p-10 rounded-[32px] border border-slate-200 shadow-sm relative overflow-hidden">
             <div className="absolute top-0 right-0 p-8 opacity-5">
               <FileText className="w-32 h-32" />
             </div>
             
             <div className="relative z-10 space-y-6">
                <div className="flex items-center gap-3">
                  <span className="bg-brand-primary/5 text-brand-primary px-3 py-1 rounded-full text-xs font-black uppercase tracking-widest">
                    {dept?.name}
                  </span>
                  <span className="text-slate-400 font-bold text-xs uppercase tracking-widest">
                    {resource.courseCode} • Semester {resource.semester}
                  </span>
                </div>

                <h1 className="text-5xl font-serif font-black text-slate-900 leading-tight">
                  {resource.title}
                </h1>

                <div className="flex items-center gap-6 text-sm font-medium text-slate-500">
                  <div className="flex items-center gap-1.5">
                    <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                    <span className="text-slate-900 font-bold">{resource.rating}</span>
                    <span>({resource.reviewCount} Reviews)</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Download className="w-4 h-4" />
                    <span>{resource.downloadCount} Downloads</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Clock className="w-4 h-4" />
                    <span>
                      Updated {
                        resource.updatedAt instanceof Timestamp 
                        ? resource.updatedAt.toDate().toLocaleDateString()
                        : (resource.updatedAt?.seconds 
                          ? new Date(resource.updatedAt.seconds * 1000).toLocaleDateString() 
                          : new Date(resource.updatedAt).toLocaleDateString())
                      }
                    </span>
                  </div>
                </div>

                <div className="pt-6 border-t border-slate-100">
                  <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-4">Description</h3>
                  <p className="text-slate-600 text-lg leading-relaxed whitespace-pre-line">
                    {resource.description}
                  </p>
                </div>

                <div className="flex flex-wrap gap-2 pt-4">
                  {resource.tags.map(tag => (
                    <span key={tag} className="bg-slate-100 text-slate-600 px-3 py-1 rounded-lg text-xs font-bold">
                      #{tag}
                    </span>
                  ))}
                </div>
             </div>
          </div>
        </div>

        {/* Action Sidebar */}
        <div className="space-y-6">
          <div className="bg-slate-900 p-8 rounded-[32px] text-white space-y-8 sticky top-24">
            <div>
              <div className="text-[10px] font-black uppercase tracking-[0.2em] text-white/40 mb-2">Access Type</div>
              <div className="flex items-center justify-between">
                 <div className="text-3xl font-serif font-black">
                   {resource.isFree ? "Free" : `${resource.price} Credits`}
                 </div>
                 <div className={cn(
                    "px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider border",
                    resource.isFree ? "bg-green-500/20 border-green-500/30 text-green-400" : "bg-brand-secondary/20 border-brand-secondary/30 text-brand-secondary"
                 )}>
                   {resource.type}
                 </div>
              </div>
            </div>

            <div className="space-y-4">
              {hasAccess ? (
                <div className="space-y-4">
                  <div className="p-4 bg-green-500/10 border border-green-500/20 rounded-2xl flex items-center gap-3 text-green-400">
                    <CheckCircle2 className="w-6 h-6 shrink-0" />
                    <span className="text-sm font-bold">You have full access to this resource.</span>
                  </div>
                  <Button 
                    className="w-full h-14 text-lg bg-white text-slate-900 hover:bg-slate-100 border-none"
                    onClick={handleDownload}
                  >
                    <Download className="w-5 h-5 mr-2" /> Download Resource
                  </Button>
                </div>
              ) : (
                <div className="space-y-6">
                  <div className="p-4 bg-white/5 border border-white/10 rounded-2xl flex items-start gap-3">
                    <Lock className="w-5 h-5 text-white/40 shrink-0 mt-0.5" />
                    <div>
                      <div className="text-sm font-bold text-white">Resource Locked</div>
                      <div className="text-xs text-white/50 mt-1">Unlock this material to download and view full content.</div>
                    </div>
                  </div>
                  
                  <div className="space-y-3">
                    <Button 
                      className="w-full h-14 text-lg bg-brand-secondary text-slate-900 hover:bg-brand-secondary/90 border-none"
                      onClick={handlePurchase}
                      loading={purchasing}
                    >
                      Unlock for {resource.price} Credits
                    </Button>
                    <div className="flex items-center justify-center gap-2 text-[10px] font-bold text-white/40 uppercase tracking-widest">
                       <Coins className="w-3 h-3" />
                       Your Balance: {profile?.credits || 0} Credits
                    </div>
                  </div>
                </div>
              )}
            </div>

            <div className="pt-8 border-t border-white/10 space-y-4">
               <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center text-white/60 font-bold">
                    {resource.uploaderName.charAt(0)}
                  </div>
                  <div>
                    <div className="text-xs font-black uppercase tracking-wider text-white/40 leading-none mb-1">Contributor</div>
                    <div className="text-sm font-bold">{resource.uploaderName}</div>
                  </div>
               </div>
               <p className="text-[10px] text-white/30 leading-relaxed italic">
                 All resources follow academic integrity guidelines. If you find any issues, please report them to system administrators.
               </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
