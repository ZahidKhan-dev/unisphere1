import { useParams } from 'react-router-dom';
import { DEPARTMENTS } from '../constants';
import { Explore } from './Explore';

export function DepartmentPage() {
  const { id } = useParams();
  const department = DEPARTMENTS.find(d => d.id === id);

  if (!department) {
    return (
      <div className="text-center py-20">
        <h1 className="text-4xl font-serif font-black text-slate-900 mb-4">Department Not Found</h1>
        <p className="text-slate-500">The department ID "{id}" does not exist in our catalog.</p>
      </div>
    );
  }

  return (
    <div className="space-y-12">
      <div className="relative h-64 bg-brand-primary rounded-[32px] overflow-hidden flex flex-col justify-center px-12 text-white">
        <div className="absolute top-0 right-0 w-1/3 h-full opacity-10 pointer-events-none">
          <svg className="w-full h-full fill-white" viewBox="0 0 100 100" preserveAspectRatio="none">
            <path d="M0 100 C 20 0 50 0 100 100 Z" />
          </svg>
        </div>
        <div className="relative z-10 space-y-4">
          <div className="inline-block px-3 py-1 bg-white/10 backdrop-blur rounded-full text-xs font-bold uppercase tracking-wider">
            {department.code} Department
          </div>
          <h1 className="text-5xl font-serif font-black leading-tight tracking-tight max-w-2xl">
            {department.name}
          </h1>
          <p className="text-blue-100 text-lg max-w-xl font-medium opacity-80">
            Access specialized notes, project solutions, and curated study materials for {department.name}.
          </p>
        </div>
      </div>

      <Explore initialDept={id} />
    </div>
  );
}
