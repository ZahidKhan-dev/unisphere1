import { useState, useMemo } from 'react';
import { Search, Filter, SlidersHorizontal } from 'lucide-react';
import { useCollection } from '../hooks/useCollection';
import { Resource } from '../types';
import { ResourceGrid } from '../components/resources/ResourceGrid';
import { DEPARTMENTS, RESOURCE_TYPES, SEMESTERS } from '../constants';
import { Button } from '../components/common/Button';
import { where, orderBy, QueryConstraint } from 'firebase/firestore';

export function Explore({ initialDept = 'all' }: { initialDept?: string }) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDept, setSelectedDept] = useState(initialDept);
  const [selectedType, setSelectedType] = useState('all');
  const [selectedSemester, setSelectedSemester] = useState('all');
  const [sortBy, setSortBy] = useState<'latest' | 'popular' | 'rating'>('latest');

  // Reactively build constraints
  const constraints = useMemo(() => {
    const list: QueryConstraint[] = [];
    if (selectedDept !== 'all') list.push(where('departmentId', '==', selectedDept));
    if (selectedType !== 'all') list.push(where('type', '==', selectedType));
    if (selectedSemester !== 'all') list.push(where('semester', '==', Number(selectedSemester)));
    
    if (sortBy === 'latest') list.push(orderBy('createdAt', 'desc'));
    if (sortBy === 'popular') list.push(orderBy('downloadCount', 'desc'));
    if (sortBy === 'rating') list.push(orderBy('rating', 'desc'));
    
    return list;
  }, [selectedDept, selectedType, selectedSemester, sortBy]);

  const { data: resources, loading } = useCollection<Resource>('resources', constraints);

  const filteredResources = resources.filter(res => 
    res.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    res.courseCode.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-8">
      <header className="space-y-4">
        <h1 className="text-4xl font-serif font-black text-slate-900 leading-tight">Explore Resources</h1>
        <p className="text-slate-500 font-medium max-w-2xl">
          Search thousands of academic materials shared by verified contributors across all departments.
        </p>
      </header>

      {/* Filter Bar */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-6">
        <div className="flex flex-col lg:flex-row gap-4 items-center">
          <div className="relative flex-1 group w-full">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 group-focus-within:text-brand-primary transition-colors" />
            <input 
              type="text" 
              placeholder="Search by title or course code..."
              className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 pl-12 pr-4 outline-none focus:ring-2 focus:ring-brand-primary/10 focus:border-brand-primary transition-all text-sm font-medium"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <div className="flex items-center gap-2 w-full lg:w-auto">
            <div className="relative w-full lg:w-48">
              <SlidersHorizontal className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <select 
                className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 pl-10 pr-4 outline-none text-sm font-medium appearance-none cursor-pointer"
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
              >
                <option value="latest">Latest First</option>
                <option value="popular">Most Popular</option>
                <option value="rating">Highest Rated</option>
              </select>
            </div>
            <Button variant="outline" className="lg:hidden w-full gap-2">
              <Filter className="w-4 h-4" /> Filters
            </Button>
          </div>
        </div>

        <div className="hidden lg:flex flex-wrap gap-3 items-center pt-2 border-t border-slate-50">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mr-2">Quick Filters:</span>
          
          <select 
            className="text-xs font-bold text-slate-600 bg-white border border-slate-200 rounded-full px-4 py-1.5 outline-none hover:bg-slate-50 transition-colors"
            value={selectedDept}
            onChange={(e) => setSelectedDept(e.target.value)}
          >
            <option value="all">All Departments</option>
            {DEPARTMENTS.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
          </select>

          <select 
            className="text-xs font-bold text-slate-600 bg-white border border-slate-200 rounded-full px-4 py-1.5 outline-none hover:bg-slate-50 transition-colors"
            value={selectedType}
            onChange={(e) => setSelectedType(e.target.value)}
          >
            <option value="all">All Types</option>
            {RESOURCE_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
          </select>

          <select 
            className="text-xs font-bold text-slate-600 bg-white border border-slate-200 rounded-full px-4 py-1.5 outline-none hover:bg-slate-50 transition-colors"
            value={selectedSemester}
            onChange={(e) => setSelectedSemester(e.target.value)}
          >
            <option value="all">All Semesters</option>
            {SEMESTERS.map(s => <option key={s} value={s}>Semester {s}</option>)}
          </select>

          {(selectedDept !== 'all' || selectedType !== 'all' || selectedSemester !== 'all') && (
            <button 
              onClick={() => { setSelectedDept('all'); setSelectedType('all'); setSelectedSemester('all'); }}
              className="text-[10px] font-bold text-red-500 hover:underline ml-2"
            >
              Clear Filters
            </button>
          )}
        </div>
      </div>

      <div className="pb-12">
        <div className="flex items-center justify-between mb-8 px-2">
          <div className="text-sm text-slate-500 font-medium">
            Showing <span className="text-slate-900 font-bold">{filteredResources.length}</span> results
          </div>
          <div className="flex gap-2">
            {/* View Mode Toggles could go here */}
          </div>
        </div>
        
        <ResourceGrid resources={filteredResources} loading={loading} />
      </div>
    </div>
  );
}
