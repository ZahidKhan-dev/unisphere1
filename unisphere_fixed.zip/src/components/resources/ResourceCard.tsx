import { FileText, Download, Star } from 'lucide-react';
import { Resource } from '../../types';
import { Button } from '../common/Button';
import { cn } from '../../lib/utils';
import { DEPARTMENTS } from '../../constants';
import { useNavigate } from 'react-router-dom';

interface ResourceCardProps {
  resource: Resource;
  onClick?: () => void;
  key?: string;
}

export function ResourceCard({ resource }: ResourceCardProps) {
  const dept = DEPARTMENTS.find(d => d.id === resource.departmentId);
  const navigate = useNavigate();

  return (
    <div 
      className="group bg-white rounded-xl border border-slate-200 overflow-hidden hover:shadow-xl hover:shadow-slate-200/50 transition-all duration-300 flex flex-col h-full cursor-pointer"
      onClick={() => navigate(`/resource/${resource.id}`)}
    >
      <div className="relative h-32 bg-slate-100 flex items-center justify-center group-hover:bg-brand-primary/5 transition-colors">
        <div className="absolute top-3 left-3 flex gap-1.5 flex-wrap pr-3">
          <span className="bg-white/80 backdrop-blur px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider text-slate-600 border border-slate-100">
            {resource.type}
          </span>
          {resource.isFree ? (
            <span className="bg-green-500/10 text-green-600 px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider border border-green-200">
              Free
            </span>
          ) : (
            <span className="bg-brand-secondary/10 text-brand-secondary-dark px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider border border-brand-secondary/20">
              Paid
            </span>
          )}
        </div>
        <FileText className="w-12 h-12 text-slate-300 group-hover:text-brand-primary/40 transition-colors" />
      </div>

      <div className="p-5 flex-1 flex flex-col">
        <div className="flex items-center gap-2 mb-2">
          <span className="text-[10px] font-bold text-brand-primary uppercase bg-brand-primary/5 px-2 py-0.5 rounded">
            {dept?.code || "GEN"}
          </span>
          <span className="text-[10px] font-medium text-slate-400 capitalize">
            {resource.courseCode} • Sem {resource.semester}
          </span>
        </div>

        <h3 className="font-serif text-lg font-bold text-slate-900 line-clamp-1 mb-2 group-hover:text-brand-primary transition-colors">
          {resource.title}
        </h3>
        
        <p className="text-sm text-slate-500 line-clamp-2 mb-4 leading-relaxed">
          {resource.description}
        </p>

        <div className="mt-auto flex items-center justify-between text-[11px] text-slate-400 font-medium">
          <div className="flex items-center gap-1.5">
            <Star className={cn("w-3.5 h-3.5", resource.rating > 0 ? "text-yellow-400 fill-yellow-400" : "text-slate-200")} />
            <span className="text-slate-700 font-bold">{resource.rating || "N/A"}</span>
            <span className="opacity-60">({resource.reviewCount})</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Download className="w-3.5 h-3.5" />
            <span>{resource.downloadCount} downloads</span>
          </div>
        </div>
      </div>

      <div className="px-5 py-4 border-t border-slate-50 bg-slate-50/30 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-full bg-slate-200 border border-white"></div>
          <span className="text-[11px] text-slate-500 font-medium truncate max-w-[80px]">By {resource.uploaderName}</span>
        </div>
        <Button size="sm" variant="ghost" className="text-brand-primary h-8 px-2 hover:bg-brand-primary/5">
          View Detail
        </Button>
      </div>
    </div>
  );
}
