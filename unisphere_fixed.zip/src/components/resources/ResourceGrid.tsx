import { Resource } from '../../types';
import { ResourceCard } from './ResourceCard';

interface ResourceGridProps {
  resources: Resource[];
  loading?: boolean;
}

export function ResourceGrid({ resources, loading }: ResourceGridProps) {
  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
          <div key={i} className="bg-white rounded-xl border border-slate-200 h-[380px] animate-pulse">
            <div className="h-32 bg-slate-100"></div>
            <div className="p-5">
              <div className="h-3 w-20 bg-slate-100 mb-4 rounded"></div>
              <div className="h-5 w-40 bg-slate-100 mb-2 rounded"></div>
              <div className="h-4 w-full bg-slate-100 mb-1 rounded"></div>
              <div className="h-4 w-full bg-slate-100 mb-6 rounded"></div>
              <div className="flex justify-between">
                <div className="h-3 w-16 bg-slate-100 rounded"></div>
                <div className="h-3 w-16 bg-slate-100 rounded"></div>
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (resources.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center">
        <div className="bg-slate-100 p-6 rounded-full mb-4">
          <svg className="w-12 h-12 text-slate-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
          </svg>
        </div>
        <h3 className="text-xl font-serif font-bold text-slate-900 mb-2">No resources found</h3>
        <p className="text-slate-500 max-w-sm">
          We couldn't find any resources matching your criteria. Try adjusting your filters or be the first to upload one!
        </p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
      {resources.map((resource) => (
        <ResourceCard key={resource.id} resource={resource} />
      ))}
    </div>
  );
}
