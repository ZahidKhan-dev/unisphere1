import { ReactNode } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';

interface ProtectedRouteProps {
  children: ReactNode;
}

export function ProtectedRoute({ children }: ProtectedRouteProps) {
  const { profile, loading } = useAuth();
  const location = useLocation();

  if (loading) {
    return <div className="p-10 text-center font-serif flex items-center justify-center min-h-[50vh]">Verifying credentials...</div>;
  }

  if (!profile) {
    return <Navigate to="/" state={{ from: location }} replace />;
  }

  return <>{children}</>;
}

export function AdminRoute({ children }: ProtectedRouteProps) {
  const { profile, loading } = useAuth();
  const location = useLocation();

  if (loading) {
    return <div className="p-10 text-center font-serif flex items-center justify-center min-h-[50vh]">Authenticating administrator...</div>;
  }

  if (!profile || profile.role !== 'admin') {
    return <Navigate to="/student" replace />;
  }

  return <>{children}</>;
}
