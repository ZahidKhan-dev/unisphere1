import { Search, Bell, User as UserIcon, Coins, LayoutDashboard } from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { Button } from '../common/Button';
import { useLocation, Link } from 'react-router-dom';

export function Header() {
  const { profile, signIn, logout } = useAuth();
  const location = useLocation();
  const isAdminOnStudentSide = profile?.role === 'admin' && location.pathname !== '/admin';

  return (
    <header className="h-16 bg-white/80 backdrop-blur-md border-b border-slate-200 flex items-center justify-between px-8 sticky top-0 z-10 ml-64">
      <div className="flex-1 max-w-xl flex items-center gap-4">
        <div className="relative group flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 group-focus-within:text-brand-primary transition-colors" />
          <input 
            type="text" 
            placeholder="Search for courses, notes, or help..."
            className="w-full bg-slate-100 border-none rounded-full py-2 pl-10 pr-4 text-sm focus:ring-2 focus:ring-brand-primary/20 bg-slate-50 transition-all outline-none"
          />
        </div>
        
        {isAdminOnStudentSide && (
          <div className="flex items-center gap-3">
            <span className="text-[10px] bg-amber-50 text-amber-600 px-2 py-1 rounded border border-amber-200 font-bold uppercase tracking-wider">
              Preview Mode (Admin)
            </span>
            <Link to="/admin">
              <Button variant="outline" size="sm" className="gap-2 text-xs py-1.5 h-8">
                <LayoutDashboard className="w-3 h-3" />
                Back to Admin Panel
              </Button>
            </Link>
          </div>
        )}
      </div>

      <div className="flex items-center gap-4">
        {profile ? (
          <>
            <div className="flex items-center gap-2 bg-slate-100 px-3 py-1.5 rounded-full border border-slate-200">
              <Coins className="w-4 h-4 text-brand-secondary fill-brand-secondary/20" />
              <span className="text-sm font-semibold">{profile.credits} <span className="text-[10px] text-slate-500 uppercase">Credits</span></span>
            </div>
            
            <button className="p-2 text-slate-500 hover:bg-slate-100 rounded-full transition-colors relative">
              <Bell className="w-5 h-5" />
              <span className="absolute top-2 right-2.5 w-2 h-2 bg-red-500 rounded-full border-2 border-white"></span>
            </button>

            <div className="flex items-center gap-3 pl-4 border-l border-slate-200">
              <div className="text-right hidden sm:block">
                <div className="text-sm font-medium text-slate-900 leading-none">{profile.displayName}</div>
                <div className="text-[10px] text-slate-500 uppercase tracking-wider mt-1">{profile.role}</div>
              </div>
              <button 
                onClick={() => logout()}
                className="w-9 h-9 rounded-full bg-brand-primary/10 flex items-center justify-center overflow-hidden border border-brand-primary/20 hover:scale-105 transition-transform"
              >
                {profile.photoURL ? (
                  <img src={profile.photoURL} alt={profile.displayName} className="w-full h-full object-cover" />
                ) : (
                  <UserIcon className="w-5 h-5 text-brand-primary" />
                )}
              </button>
            </div>
          </>
        ) : (
          <Button onClick={() => signIn()}>Sign In with Google</Button>
        )}
      </div>
    </header>
  );
}
