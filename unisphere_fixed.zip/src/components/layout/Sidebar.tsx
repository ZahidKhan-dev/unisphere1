import { Link, useLocation } from 'react-router-dom';
import { 
  Home, 
  Search, 
  Upload, 
  BookOpen, 
  HelpCircle, 
  Settings, 
  ChevronRight,
  GraduationCap,
  LayoutDashboard,
  Shield
} from 'lucide-react';
import { DEPARTMENTS } from '../../constants';
import { cn } from '../../lib/utils';
import { useAuth } from '../../hooks/useAuth';

export function Sidebar() {
  const location = useLocation();
  const { profile } = useAuth();

  const navItems = [
    { name: 'Home', icon: Home, path: '/' },
    { name: 'Explore', icon: Search, path: '/explore' },
    { name: 'Upload', icon: Upload, path: '/upload' },
    { name: 'Help Hub', icon: HelpCircle, path: '/help' },
  ];

  if (profile?.role === 'admin') {
    navItems.push({ name: 'Admin Panel', icon: LayoutDashboard, path: '/admin' });
  }

  return (
    <aside className="w-64 bg-white border-r border-slate-200 flex flex-col h-screen fixed left-0 top-0 z-20">
      <div className="p-6 flex items-center gap-3">
        <div className="bg-brand-primary p-2 rounded-lg">
          <GraduationCap className="w-6 h-6 text-white" />
        </div>
        <span className="font-serif text-2xl font-bold text-brand-primary tracking-tight">UniSphere</span>
      </div>

      <nav className="flex-1 px-4 py-4 space-y-1 overflow-y-auto">
        <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider px-3 mb-2">Main Menu</div>
        {navItems.map((item) => (
          <Link
            key={item.path}
            to={item.path}
            className={cn(
              "flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors",
              location.pathname === item.path 
                ? "bg-slate-100 text-brand-primary" 
                : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
            )}
          >
            <item.icon className="w-4 h-4" />
            {item.name}
          </Link>
        ))}

        <div className="mt-8 text-xs font-semibold text-slate-400 uppercase tracking-wider px-3 mb-2">Departments</div>
        {DEPARTMENTS.map((dept) => (
          <Link
            key={dept.id}
            to={`/department/${dept.id}`}
            className={cn(
              "flex items-center justify-between px-3 py-2 rounded-md text-sm transition-colors",
              location.pathname === `/department/${dept.id}`
                ? "bg-slate-100 text-brand-primary font-medium"
                : "text-slate-600 hover:bg-slate-50"
            )}
          >
            <span className="truncate">{dept.name}</span>
            <ChevronRight className="w-3 h-3 opacity-50" />
          </Link>
        ))}
      </nav>

      <div className="p-4 border-t border-slate-100 space-y-2">
        <Link to="/settings" className="flex items-center gap-3 px-3 py-2 rounded-md text-sm text-slate-600 hover:bg-slate-50 transition-colors">
          <Settings className="w-4 h-4" />
          Settings
        </Link>
        {profile?.role === 'admin' && (
          <Link to="/admin" className="flex items-center gap-3 px-3 py-2 rounded-md text-[10px] uppercase font-bold tracking-widest text-slate-400 hover:text-brand-primary transition-colors">
            <Shield className="w-3 h-3" />
            Admin Access
          </Link>
        )}
      </div>
    </aside>
  );
}
