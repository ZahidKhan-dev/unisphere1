export type UserRole = 'student' | 'contributor' | 'admin';
export type ResourceType = 'Notes' | 'Assignments' | 'Projects' | 'Past Papers';
export type ResourceStatus = 'pending' | 'approved' | 'rejected';

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  photoURL?: string;
  role: UserRole;
  department?: string;
  credits: number;
  isVerified: boolean;
  createdAt: any;
}

export interface Department {
  id: string;
  name: string;
  code: string;
  description: string;
}

export interface Resource {
  id: string;
  title: string;
  description: string;
  departmentId: string;
  courseCode: string;
  semester: number;
  type: ResourceType;
  fileUrl: string;
  fileType: string;
  price: number;
  isFree: boolean;
  uploaderId: string;
  uploaderName: string;
  status: ResourceStatus;
  downloadCount: number;
  rating: number;
  reviewCount: number;
  tags: string[];
  createdAt: any;
  updatedAt: any;
}

export interface HelpRequest {
  id: string;
  studentId: string;
  studentName: string;
  title: string;
  description: string;
  departmentId: string;
  status: 'open' | 'closed' | 'resolved';
  isPaid: boolean;
  budget?: number;
  responseCount: number;
  createdAt: any;
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: 'create' | 'update' | 'delete' | 'list' | 'get' | 'write';
  path: string | null;
  authInfo: {
    userId: string;
    email: string;
    emailVerified: boolean;
    isAnonymous: boolean;
    providerInfo: { providerId: string; displayName: string; email: string; }[];
  }
}
