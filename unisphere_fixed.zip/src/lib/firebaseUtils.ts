import { auth, db } from '../services/firebase';
import firebaseConfig from '../../firebase-applet-config.json';

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
  projectId?: string;
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null, shouldThrow = true) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path,
    projectId: (firebaseConfig as any).projectId || 'unknown'
  }
  const errorJson = JSON.stringify(errInfo);
  console.error('Firestore Error details:', errorJson);
  
  if (errInfo.error.includes('permissions')) {
    console.warn('%c ACTION REQUIRED: Permission Denied ', 'background: #fee2e2; color: #991b1b; font-weight: bold; padding: 4px; border-radius: 4px;');
    console.warn('1. Check if YOUR email is in the "admins" collection if trying to perform admin actions.');
    console.warn('2. Ensure your domain is authorized in Firebase > Auth > Settings.');
    console.warn('3. Verify that your rules are deployed correctly using the Firebase Console.');
  }

  if (shouldThrow) {
    throw new Error(errorJson);
  }
}
