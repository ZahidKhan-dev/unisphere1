export const DEPARTMENTS = [
  { id: 'cs', name: 'Computer Science', code: 'CS' },
  { id: 'se', name: 'Software Engineering', code: 'SE' },
  { id: 'adp', name: 'Associate Degree Programs', code: 'ADP' },
  { id: 'ece', name: 'Electrical & Computer Engineering', code: 'ECE' },
  { id: 'psych', name: 'Psychology', code: 'PSYCH' },
  { id: 'law', name: 'Law', code: 'LAW' },
  { id: 'math', name: 'Mathematics', code: 'MATH' },
  { id: 'af', name: 'Accounting & Finance', code: 'AF' },
  { id: 'me', name: 'Mechanical Engineering', code: 'ME' },
  { id: 'eng', name: 'English', code: 'ENG' },
];

export const RESOURCE_TYPES = ['Notes', 'Assignments', 'Projects', 'Past Papers'];
export const SEMESTERS = [1, 2, 3, 4, 5, 6, 7, 8];
