# Security Specification

## Data Invariants
1. A Resource must have a valid `uploaderId` matching the authenticated user during creation.
2. Only Admins can change a resource status to `approved` or `rejected`.
3. Users can only update their own profiles (except for the `role` field).
4. Approved resources are publicly readable.
5. All IDs must be valid strings.

## The Pillars
- **Auth check**: Mandatory for most writes.
- **Schema check**: `isValid[Entity]` for all writes.
- **Identity check**: `uploaderId == request.auth.uid`.

## Match Blocks
- `/users/{userId}`: Only owner can write. Role is immutable by user.
- `/departments/{deptId}`: Read by all. Write only by Admin.
- `/resources/{resId}`: Create by any signed-in user. Update status only by Admin. Update metadata only by Owner.
